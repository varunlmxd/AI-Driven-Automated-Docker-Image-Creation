from flask import Flask
from flask_cors import CORS
import logging

def create_app(config_name):
    app = Flask(__name__)
    CORS(app)
    
    app.config.from_object(f'config.{config_name.capitalize()}Config')

    from .routes.build_and_run import build_and_run_bp
    from .routes.logs import logs_bp
    app.register_blueprint(build_and_run_bp)
    app.register_blueprint(logs_bp)
    return app