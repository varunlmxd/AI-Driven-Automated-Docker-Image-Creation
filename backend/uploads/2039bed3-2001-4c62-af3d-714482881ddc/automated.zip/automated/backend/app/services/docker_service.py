from flask import jsonify
from threading import Thread
import docker
import socket
import os
import time
import logging
import queue
import shutil
import re

client = docker.from_env()

# Set up logging to be pushed to a queue
log_queue = queue.Queue()

# Logging handler that pushes logs to a queue
class QueueHandler(logging.Handler):
    def emit(self, record):
        # Filter out Flask's default access logs
        if not record.name.startswith('werkzeug'):
            log_queue.put(self.format(record))

# Custom logger for our application
logger = logging.getLogger('app')
logger.setLevel(logging.INFO)
logger.addHandler(QueueHandler())

# Helper function to stream logs from the queue
def stream_logs():
    while True:
        try:
            log = log_queue.get()  # Wait for 1 second for a new log
            yield f"data: {log}\n\n"
        except queue.Empty:
            pass 

def build_and_run_docker(file_path, data):
    try:
        logger.info("-> Dockerfile created successfully.")
        # Build Docker image
        logger.info("-> Building Docker image...")
        image, json_logs = client.images.build(path=file_path, tag=data.image_name)
        logger.info(f"-> Docker image {data.image_name} built successfully.")

        pattern = r'--port\",?\"(\d+)'
        dockerfile_path = os.path.join(file_path, 'Dockerfile')

        # Check if Dockerfile exists
        if not os.path.isfile(dockerfile_path):
            raise FileNotFoundError(f"Dockerfile not found at {dockerfile_path}")

        with open(dockerfile_path, 'r') as file:
            dockerfile_text = file.read()

        # Search for the pattern
        match = re.search(pattern, dockerfile_text)

        if match:
            local_endpoint = match.group(1)
        else:
            local_endpoint = data.endpoint

        # Run Docker container
        logger.info(f"-> Running Docker container {data.image_name}...")
        container = client.containers.run(
            data.image_name,
            name=data.image_name,
            detach=True,
            ports={f'{local_endpoint}/tcp': data.endpoint}
        )

        # Wait for a few seconds to let the container start
        time.sleep(5)

        # Check if the container is still running
        container.reload()  # Refresh the container status
        if container.status != 'running':
            logs = container.logs().decode('utf-8')  # Get container logs for debugging
            container.remove()
            time.sleep(5)
            image.reload() #reloads the image
            # Remove the image once container is removed
            client.images.remove(image=data.image_name, force=True)
            time.sleep(5)
            # Prune dangling images
            client.images.prune(filters={'dangling': True})  # Only remove dangling images
            # Clean up files and directory
            shutil.rmtree(file_path)  # Remove the directory containing the Dockerfile and zip
            return jsonify({"error": f"Container exited unexpectedly. Logs: {logs}", "status": 500}), 500

        # Get container details
        container_info = client.api.inspect_container(container.id)
        ports = container_info['NetworkSettings']['Ports']
        hostname = socket.gethostname()
        ip_address = socket.gethostbyname(hostname)

        urls = [f"http://{ip_address}:{binding[0]['HostPort']}" for port, binding in ports.items() if binding]
        logger.info(f"-> Container {data.image_name} started successfully.")
        
        # Clean up files and directory
        shutil.rmtree(file_path)  # Remove the directory containing the Dockerfile and zip

        return jsonify({"urls": urls, "status": 200})

    except Exception as e:
        logger.error(f"An error occurred: {str(e)}")
        return jsonify({"error": str(e), "status": 500}), 500
