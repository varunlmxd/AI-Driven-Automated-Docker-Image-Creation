from pydantic import BaseModel

class RunContainerRequest(BaseModel):
    endpoint: int
    image_name: str
