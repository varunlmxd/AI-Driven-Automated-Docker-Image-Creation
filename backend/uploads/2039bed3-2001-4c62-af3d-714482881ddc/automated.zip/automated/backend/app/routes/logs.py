from flask import Blueprint, jsonify, request, Response
from app.services.docker_service import stream_logs

logs_bp = Blueprint('logs', __name__)

@logs_bp.route('/api/v1/logs')
def logs():
    return Response(stream_logs(), mimetype='text/event-stream')