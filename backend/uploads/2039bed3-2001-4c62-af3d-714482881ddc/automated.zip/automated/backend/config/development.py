class DevelopmentConfig:
    DEBUG = True
    UPLOAD_FOLDER = './uploads'
