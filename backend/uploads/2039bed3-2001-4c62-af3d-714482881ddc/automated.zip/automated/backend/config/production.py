class ProductionConfig:
    DEBUG = False
    UPLOAD_FOLDER = '/var/uploads'
